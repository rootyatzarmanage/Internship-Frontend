import { useRef, useState } from 'react'
import Sidebar from './Components/layout/Sidebar'
import Header from './Components/layout/Header'
import ProjectDetails from './Components/cards/ProjectDetails'
import ProjectImage from './Components/cards/ProjectImage'
import ProjectMap from './Components/cards/ProjectMap'
import './App.css'

const SIDEBAR_STORAGE_KEY = 'overview-sidebar-collapsed'

const MIN_WIDTH = 30
const MAX_WIDTH = 75
const MIN_HEIGHT = 25
const MAX_HEIGHT = 75

const DEFAULT_WIDTH = 64
const DEFAULT_HEIGHT = 50

const clamp = (value, min, max) => Math.min(max, Math.max(min, value))

function App() {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(() => (
    window.localStorage.getItem(SIDEBAR_STORAGE_KEY) === 'true'
  ))
  const [leftPanelWidth, setLeftPanelWidth] = useState(DEFAULT_WIDTH)
  const [topPanelHeight, setTopPanelHeight] = useState(DEFAULT_HEIGHT)
  const [isDragging, setIsDragging] = useState(false)
  const panelsRef = useRef(null)

  const handleToggleSidebar = () => {
    setIsSidebarCollapsed((prev) => {
      const nextState = !prev
      window.localStorage.setItem(SIDEBAR_STORAGE_KEY, String(nextState))
      return nextState
    })
  }

  const handleDividerPointerDown = (event) => {
    if (event.button !== 0 && event.pointerType === 'mouse') return

    const container = panelsRef.current
    if (!container) return

    event.preventDefault()

    // Measured once at grab time; the grid box itself doesn't move during a drag.
    const bounds = container.getBoundingClientRect()
    const startX = event.clientX
    const startY = event.clientY
    const startWidth = leftPanelWidth
    const startHeight = topPanelHeight

    const previousCursor = document.body.style.cursor
    const previousSelect = document.body.style.userSelect
    document.body.style.cursor = 'move'
    document.body.style.userSelect = 'none'
    setIsDragging(true)

    const handlePointerMove = (moveEvent) => {
      const deltaX = ((moveEvent.clientX - startX) / bounds.width) * 100
      const deltaY = ((moveEvent.clientY - startY) / bounds.height) * 100

      setLeftPanelWidth(clamp(startWidth + deltaX, MIN_WIDTH, MAX_WIDTH))
      setTopPanelHeight(clamp(startHeight + deltaY, MIN_HEIGHT, MAX_HEIGHT))
    }

    const stopDragging = () => {
      window.removeEventListener('pointermove', handlePointerMove)
      window.removeEventListener('pointerup', stopDragging)
      window.removeEventListener('pointercancel', stopDragging)
      document.body.style.cursor = previousCursor
      document.body.style.userSelect = previousSelect
      setIsDragging(false)
    }

    window.addEventListener('pointermove', handlePointerMove)
    window.addEventListener('pointerup', stopDragging)
    window.addEventListener('pointercancel', stopDragging)
  }

  const handleDividerKeyDown = (event) => {
    const step = event.shiftKey ? 5 : 2

    switch (event.key) {
      case 'ArrowLeft':
        setLeftPanelWidth((value) => clamp(value - step, MIN_WIDTH, MAX_WIDTH))
        break
      case 'ArrowRight':
        setLeftPanelWidth((value) => clamp(value + step, MIN_WIDTH, MAX_WIDTH))
        break
      case 'ArrowUp':
        setTopPanelHeight((value) => clamp(value - step, MIN_HEIGHT, MAX_HEIGHT))
        break
      case 'ArrowDown':
        setTopPanelHeight((value) => clamp(value + step, MIN_HEIGHT, MAX_HEIGHT))
        break
      default:
        return
    }

    event.preventDefault()
  }

  const handleDividerDoubleClick = () => {
    setLeftPanelWidth(DEFAULT_WIDTH)
    setTopPanelHeight(DEFAULT_HEIGHT)
  }

  return (
    <div className="overview-shell flex h-screen min-h-0 overflow-hidden">
      <Sidebar isCollapsed={isSidebarCollapsed} />
      {!isSidebarCollapsed && (
        <button
          type="button"
          aria-label="Close sidebar"
          className="overview-sidebar-backdrop"
          onClick={() => setIsSidebarCollapsed(true)}
        />
      )}
      <main className="flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden bg-[#f7f7f7]">
        <Header onToggleSidebar={handleToggleSidebar} />
        <div
          ref={panelsRef}
          className="overview-panels grid min-h-0 flex-1"
          style={{
            '--left-panel-width': `${leftPanelWidth}fr`,
            '--right-panel-width': `${100 - leftPanelWidth}fr`,
          }}
        >
          <section className="min-h-0 min-w-0 overflow-y-auto px-5 py-9 xl:px-9">
            <ProjectDetails />
          </section>

          <button
            type="button"
            aria-label="Resize panels: left and right arrows change the column split, up and down arrows change the image and map split"
            onPointerDown={handleDividerPointerDown}
            onKeyDown={handleDividerKeyDown}
            onDoubleClick={handleDividerDoubleClick}
            className={`overview-divider group relative z-10 h-full w-2 cursor-move touch-none bg-transparent p-0 ${isDragging ? 'is-dragging' : ''}`}
          >
            {/* full-height track */}
            <span className="pointer-events-none absolute inset-y-0 left-1/2 w-1 -translate-x-1/2 bg-[#bcbcbc] transition-colors group-hover:bg-[#008cd2] group-active:bg-[#008cd2]" />
            {/* grip marker follows the current vertical split so the handle reads as 2D */}
            <span
              className="pointer-events-none absolute left-1/2 h-9 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full border border-[#bcbcbc] bg-white shadow-sm transition-colors group-hover:border-[#008cd2] group-active:border-[#008cd2]"
              style={{ top: `${topPanelHeight}%` }}
            />
          </button>

          <section className="overview-right-panel min-h-0 min-w-0 overflow-hidden px-5 py-9 xl:px-8">
            <div
              className="grid h-full min-h-0 w-full"
              style={{
                gridTemplateRows: `minmax(0, ${topPanelHeight}fr) minmax(0, ${100 - topPanelHeight}fr)`,
              }}
            >
              <ProjectImage />
              <ProjectMap />
            </div>
          </section>
        </div>
      </main>
    </div>
  )
}

export default App
